PLEASE READ ALL TEXT FILES CONTAINED WITHIN THIS ZIP ARCHIVE, THIS INCLUDES 'credits.txt' and 'license.txt'
THIS TOOL IS TO BE USED AT YOUR OWN RISK, IF YOU DO NOT KNOW WHAT THIS IS, PLEASE STOP USING THE APPLICATION AND DELETE IT.
Redsn0w is a lightweight, multi-platform jailbreaking and unlocking tool for the iPhone 2G (original iPhone), the iPhone 3G, iPhone 3GS and also the iPod touch (first generation and second generation).

--
Copyright 2007-2009 iPhone Dev-Team. All rights reserved. Not for commercial use. 
