redsn0w lite
by the iPhone Dev Team
http://blog.iphone-dev.org

A no frills tethered jailbreak for iPod Touch 2G 

-----------------------------------------------------------------------------
--> YOU WILL VERY LIKELY VOID YOUR WARRANTY BY USING THIS <--

This is to be used only at your own risk.

We do not accept any responsibility for any damage that this tool may help
you cause to any of your equipment.

--> USE AT YOUR OWN RISK!!!!! <--
-----------------------------------------------------------------------------

WE WILL BE PROVIDING ABSOLUTELY NO SUPPORT FOR THIS!!!!!
If you post comments on our blog looking for support, we reserve the
right to ban your user ID from the blog.  You really shouldn't be doing
this unless you understand it all enough to not need support!

-----------------------------------------------------------------------------

THIS IS A *****  TETHERED ***** JAILBREAK 
IF YOU DON'T KNOW EXACTLY WHAT THAT MEANS, DON'T USE THIS!

There are many ways to do this.  Here's one way that will probably
work for you.  If it doesn't, please don't come to use for support.
We're working on an untethered version.

This is for Mac only.  But you should be able to find (or work out
on your own) how to do it on Windows or Linux too.

-----------------------------------------------------------------------------
rslite
-----------------------------------------------------------------------------
This is an interface to the DFU and Recovery modes of the device.  It
requires you to have libusb installed on your Mac.

Due to buggy interaction between libusb and the Apple device, any output
that is long gets all chewed up.  But if you stick to just the "!" and
the "#" commands, you won't notice.  We don't normally use this tool
but it's a lot easier to distribute and compile than the GUI we use.

The "!" (exclamation point, no quotes when you use it) sends a file.
The "#" (pound sign, no quotes when you use it) sends a script.
In both cases, you name the file right after the symbol.


-----------------------------------------------------------------------------
Basic instructions
-----------------------------------------------------------------------------
Note: these are the bare bones instructions.   Please don't come to us
looking for more detailed instructions.

Preparation
1) Copy the FirmwareBundles and CustomPackages directories into
   your PwnageTool.app/Contents/Resources directory
2) Create a custom 2.2.1 ipsw with PwnageTool in Advanced mode.  Don't
   enable custom boot logos.  
3) From your custom 2.2.1 ipsw, extract these (patched) files:
   iBSS.n72ap.RELEASE.dfu    (name it iBSS221pwn.dfu)
   iBoot.n72ap.RELEASE.img3  (name it iBoot221pwn.img3)
4) From the official 2.1.1 ipsw, extract this (unpatched) file:
   iBSS.n72ap.RELEASE.dfu    (name it iBSS211.dfu)

Installing the jailbroken custom ipsw
5) Put your ipt2g into DFU mode using keypresses.  Don't have iTunes running!
6) Start rslite.  Send the official iBSS from 2.1.1:    !iBSS211.dfu
7) Start rslite again.  Send the redsn0w-lite patch:    #pwn211ibss.txt
8) Send the patched iBSS from 2.2.1:                    !iBSS221pwn.dfu
9) Use iTunes to do a full restore using your custom 2.2.1 ipsw

Tethered boot
After the install, your ipt2g will not be bootable without assistance
from a tethered computer.  The method in this README.txt requires you
to go into DFU mode, but you should be able to find (or work out on
your own) other more convenient ways.
10) Repeat steps 5-8
11) Send the patched iBoot from 2.2.1:                  !iBoot221pwn.img3

Your homescreen should soon show up.  You can then start iTunes.





