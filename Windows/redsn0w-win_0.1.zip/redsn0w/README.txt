redsn0w
-------

This release is only for iPod touch 2G. Versions are available for Windows,
Linux and Mac.

INSTRUCTIONS FOR WINDOWS
------------------------

It is recommended NOT to connect the iPod through any sort of USB hub.

	1. Either connect the iPod in DFU mode to the computer
           OR
           Follow the step-by-step DFU instructions with the program

	2. Launch redsn0w.exe by double-clicking on it.

NOTE FOR MACS
-------------

In versions of OS X above 10.5.6, DFU mode has been disabled by a bug in the
operating system that Apple has not yet seen fit to fix. A work-around for
this problem is connecting the iPod through a powered USB hub rather than
directly through the computer. It's also possible to use a software hack to
temporarily fix this problem to use this software. Please see the blog post at
http://blog.iphone-dev.org/post/74278878/close-the-stable-door for more
details.

	1. Either connect the iPod in DFU mode to the computer
           OR
           Follow the step-by-step DFU instructions with the program
	2. Start Terminal (in the Utilities folder under Applications)
	3. Type 'cd ' (cd space)
	4. Drag the redsn0w folder into the Terminal window
	5. Push enter
	6. Type './redsn0w' and push enter

NOTE FOR LINUX
--------------

libcurl, bzip2, zlib, openssl, libusb and libpng are required libraries. It is
recommended NOT to connect the iPod through any sort of USB hub. Due to a bug
within libusb, it is currently required that you disconnect and reconnect the
iPod when prompted during the process.


	1. Either connect the iPod in DFU mode to the computer
           OR
           Follow the step-by-step DFU instructions with the program

	2. Launch redsn0w.x86 or redsn0w.64 from the command-line as
           appropriate

CREDITS
-------

implementation (c) 2009 iPhone Dev Team
vulnerability: pod2g, MuscleNerd
exploit: planetbeing, CPICH, posixninja, chronic

LEGAL
-----

This work is copyrighted with all rights reserved. Modification or
redistribution without written consent is expressly prohibited.

