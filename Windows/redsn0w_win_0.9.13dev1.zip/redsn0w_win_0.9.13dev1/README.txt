PLEASE READ ALL TEXT FILES CONTAINED WITHIN THIS ZIP ARCHIVE.
THIS INCLUDES 'credits.txt' and 'license.txt'

THIS TOOL IS TO BE USED AT YOUR OWN RISK, IF YOU DO NOT KNOW WHAT THIS IS,
PLEASE STOP USING THE APPLICATION AND DELETE IT.

redsn0w is a lightweight, multi-platform jailbreaking, unlocking and
customizing tool for the iPhone 2G, iPhone 3G, iPhone 3GS, iPhone4, iPhone4S,
iPod touch 1G, iPod touch 2G, iPod touch 3G, iPod touch 4G,
iPad1, and iPad2

--
Copyright 2007-2012 iPhone Dev-Team. 
All rights reserved.
Not for commercial use. 
