PLEASE READ ALL TEXT FILES CONTAINED WITHIN THIS ZIP ARCHIVE.
THIS INCLUDES 'credits.txt' and 'license.txt'

THIS TOOL IS TO BE USED AT YOUR OWN RISK, IF YOU DO NOT KNOW WHAT THIS IS,
PLEASE STOP USING THE APPLICATION AND DELETE IT.

redsn0w is a lightweight, multi-platform jailbreaking, unlocking and
customizing tool for the iPhone 2G (original iPhone), iPhone 3G, iPhone 3GS, iPhone4
iPod touch 1G, iPod touch 2G, iPod touch 3G, and iPod touch 4G

--
Copyright 2007-2011 iPhone Dev-Team. 
All rights reserved.
Not for commercial use. 
