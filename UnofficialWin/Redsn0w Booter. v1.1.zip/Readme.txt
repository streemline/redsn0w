The most simple bootloader out there!
Current boot time: 4 seconds
To run: Simply extract and run Redsn0w Booter.exe
Simple!

Made by Deeboy55
Credit to
Chronic and Btbn For patches
